class EjercicioDeEstructuraDeControl3 {
    public static void main(String[] args) {
        int suma = 0;

        for (int numero = 1; numero <= 50; numero++) {
            suma += numero;
        }

        System.out.println("La suma de los primeros 50 números naturales es: " + suma);
    }
}