class EjerciciosDeEstructurasDeControl2 {
    public static void main(String[] args) {
        for (int numero = 1; numero <= 100; numero += 2) {
            System.out.println(numero);
        }
    }
}